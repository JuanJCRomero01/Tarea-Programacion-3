import React from 'react'

export const SeachItems = ({items}) => {
    return (
        <div className='container_search'>
            <p style={{textTransform: 'capitalize'}}>{items.text}</p>
        </div>
    )
}
