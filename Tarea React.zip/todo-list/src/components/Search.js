import React, { useState } from 'react'
import { getTodoByName } from '../helpers/getTodoByName'
import { SeachItems } from './SeachItems'
import { IoIosArrowBack } from 'react-icons/io';
import { useNavigate } from 'react-router-dom';



export const Search = () => {

    const [value, setValue] = useState('')

    const handlenChange = (e) => {
        setValue(e.target.value)
    }

    const navigate = useNavigate()
    const handlenBack = () => {
        navigate('/')
    }
    const todos = getTodoByName(value)

    return (
        <>
            <button
                className='back'
                onClick={handlenBack}
            >
                <IoIosArrowBack/>
                Back
            </button>
            <div>
                    <input
                        type='text'
                        placeholder='Search'
                        className='todo-input search-input'
                        value={value}
                        onChange={handlenChange}
                    />
                <div>
                    {
                        (value === '')
                            ? <p>Search a todo</p>
                            : (todos.length === 0)
                            && <p>No result</p>
                    }
                </div>
                <div>
                    {
                        todos.map(items => (
                            <SeachItems items = {items} key={items.id}/>
                        ))
                    }
                </div>
            </div>
        </>
    )
}
