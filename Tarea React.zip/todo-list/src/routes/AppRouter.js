import React from 'react'
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Search } from '../components/Search';
import TodoList from '../components/TodoList';

export const  AppRouter = () => {
    return (
    <BrowserRouter>
        <Routes>
            <Route path="/" element={<TodoList/>} />
            <Route path="/search" element={<Search/>} />
        </Routes>
    </BrowserRouter>
    )
}
