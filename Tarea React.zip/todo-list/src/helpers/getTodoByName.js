export const getTodoByName = (name = '') => {
    const todos = JSON.parse(localStorage.getItem('todos') || [])


    if(name.length === 0) {
        return []
    }
    name = name.toLowerCase()

    return todos.filter(todo => todo.text.toLowerCase().includes(name))

}
